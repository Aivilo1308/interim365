# Paramètres Globaux et Workflow - Documentation

## Vue d'ensemble

Cette solution complète permet la gestion des paramètres globaux et du workflow de validation dans l'application Django de gestion des intérimaires.

## Structure des fichiers

```
mainapp/
├── views_parametres.py          # Vues pour la gestion des paramètres
├── urls_parametres.py           # URLs dédiées aux paramètres
├── models_parametres.py         # Modèles de données (à intégrer dans models.py)
│
└── templates/
    └── parametres/
        ├── dashboard.html           # Dashboard principal des paramètres
        │
        ├── config_kelio/
        │   ├── liste.html           # Liste des configurations API Kelio
        │   └── form.html            # Formulaire de configuration
        │
        ├── config_scoring/
        │   ├── liste.html           # Liste des configurations scoring
        │   └── form.html            # Formulaire de configuration
        │
        ├── cache_kelio/
        │   └── liste.html           # Gestion du cache API
        │
        ├── workflow/
        │   ├── liste.html           # Liste des étapes de workflow
        │   └── form.html            # Formulaire d'étape
        │
        ├── departements/
        │   ├── liste.html           # Liste des départements
        │   └── form.html            # Formulaire département
        │
        ├── sites/
        │   ├── liste.html           # Liste des sites
        │   └── form.html            # Formulaire site
        │
        ├── postes/
        │   ├── liste.html           # Liste des postes
        │   └── form.html            # Formulaire poste
        │
        └── motifs_absence/
            ├── liste.html           # Liste des motifs d'absence
            └── form.html            # Formulaire motif
```

## Installation

### 1. Intégrer les modèles

Ajoutez le contenu de `models_parametres.py` à votre fichier `models.py` existant ou importez-le :

```python
# Dans models.py
from .models_parametres import (
    ConfigurationApiKelio,
    ConfigurationScoring,
    CacheApiKelio,
    WorkflowEtape,
    MotifAbsence,
)
```

### 2. Configurer les URLs

Dans votre fichier `urls.py` principal, ajoutez :

```python
from django.urls import path, include

urlpatterns = [
    # ... autres URLs ...
    path('parametres/', include('mainapp.urls_parametres')),
]
```

### 3. Effectuer les migrations

```bash
python manage.py makemigrations mainapp
python manage.py migrate
```

### 4. Mettre à jour le lien dans index_n3_global.html

Modifiez la ligne :
```html
<a href="{% url 'admin_config' %}" class="admin-action">
```

Par :
```html
<a href="{% url 'parametres_dashboard' %}" class="admin-action">
```

## Fonctionnalités

### Dashboard Principal (`/parametres/`)
- Vue d'ensemble de toutes les configurations
- Statistiques en temps réel
- Accès rapide aux actions courantes (test API, purge cache, export/import)

### Configuration API Kelio
- Gestion des connexions à l'API Kelio
- Test de connexion intégré
- Configuration des timeouts et tentatives
- Historique des synchronisations

### Configuration Scoring
- Paramétrage des critères de scoring des candidats
- Poids personnalisables (expérience, compétences, disponibilité, proximité)
- Seuils et bonus configurables

### Cache API Kelio
- Visualisation du cache
- Purge sélective ou totale
- Statistiques d'utilisation

### Workflow de Validation
- Définition des étapes de validation
- Réorganisation par drag & drop
- Configuration des délais et escalades
- Notifications email automatiques

### Gestion des Entités
- **Départements** : CRUD complet avec gestion du manager
- **Sites** : CRUD avec géolocalisation et responsable
- **Postes** : Liaison département/site, niveaux de responsabilité
- **Motifs d'absence** : Types, couleurs, intégration Kelio

## APIs et Actions

### Actions AJAX disponibles

| URL | Méthode | Description |
|-----|---------|-------------|
| `/parametres/config-kelio/tester/` | POST | Test connexion API |
| `/parametres/cache-kelio/purger/` | POST | Purge du cache |
| `/parametres/workflow/reordonner/` | POST | Réordonner étapes |
| `/parametres/departements/<pk>/toggle-actif/` | POST | Activer/Désactiver |
| `/parametres/sites/<pk>/toggle-actif/` | POST | Activer/Désactiver |
| `/parametres/postes/<pk>/toggle-actif/` | POST | Activer/Désactiver |

### Export/Import

- Export JSON : `/parametres/export/?format=json&tables=all`
- Import JSON : POST vers `/parametres/import/` avec fichier

## Sécurité

- Toutes les vues sont protégées par `@login_required`
- Accès restreint aux profils `ADMIN` et `RH`
- Logging de toutes les actions dans les fichiers de log
- Protection CSRF sur toutes les requêtes POST

## Personnalisation

### Ajouter un nouveau type de validateur

Dans `WorkflowEtape.TYPE_VALIDATEUR_CHOICES`, ajoutez :
```python
('NOUVEAU_TYPE', 'Libellé du nouveau type'),
```

### Modifier les poids par défaut du scoring

Dans `ConfigurationScoring`, modifiez les valeurs `default` des champs `poids_*`.

### Ajouter un nouveau type de cache

Dans `CacheApiKelio.TYPE_DONNEE_CHOICES`, ajoutez le nouveau type.

## Dépendances JavaScript

- **SweetAlert2** : Pour les confirmations et notifications
- **FontAwesome** : Pour les icônes
- **Bootstrap 5** : Pour la mise en page

## Support

Pour toute question ou problème, consultez les logs dans :
- `/logs/interim.log` : Actions générales
- `/logs/actions.log` : Actions utilisateurs
- `/logs/errors.log` : Erreurs

# urls_parametres.py
"""
URLs pour la gestion des paramètres globaux et workflow.
À inclure dans le fichier urls.py principal avec:
    path('parametres/', include('mainapp.urls_parametres')),
"""

from django.urls import path
from . import views_parametres

urlpatterns = [
    # ================================================================
    # DASHBOARD PRINCIPAL PARAMÈTRES
    # ================================================================
    path('', views_parametres.parametres_dashboard, name='parametres_dashboard'),
    
    # ================================================================
    # CONFIGURATION API KELIO (SINGLETON)
    # ================================================================
    path('config-kelio/', views_parametres.config_kelio_liste, name='config_kelio_liste'),
    path('config-kelio/modifier/', views_parametres.config_kelio_modifier, name='config_kelio_modifier'),
    path('config-kelio/tester/', views_parametres.config_kelio_tester, name='config_kelio_tester'),
    path('config-kelio/toggle-actif/', views_parametres.config_kelio_toggle_actif, name='config_kelio_toggle_actif'),
    path('config-kelio/vider-cache/', views_parametres.config_kelio_vider_cache, name='config_kelio_vider_cache'),
    path('config-kelio/sync/', views_parametres.lancer_sync_kelio, name='lancer_sync_kelio'),
    
    # ================================================================
    # CONFIGURATION SCORING (SINGLETON)
    # ================================================================
    path('config-scoring/', views_parametres.config_scoring_liste, name='config_scoring_liste'),
    path('config-scoring/modifier/', views_parametres.config_scoring_modifier, name='config_scoring_modifier'),
    path('config-scoring/toggle-actif/', views_parametres.config_scoring_toggle_actif, name='config_scoring_toggle_actif'),
    path('config-scoring/reinitialiser/', views_parametres.config_scoring_reinitialiser, name='config_scoring_reinitialiser'),
    
    # ================================================================
    # CACHE API KELIO
    # ================================================================
    path('cache-kelio/', views_parametres.cache_kelio_liste, name='cache_kelio_liste'),
    path('cache-kelio/purger/', views_parametres.cache_kelio_purger, name='cache_kelio_purger'),
    path('cache-kelio/<int:pk>/supprimer/', views_parametres.cache_kelio_supprimer, name='cache_kelio_supprimer'),
    
    # ================================================================
    # WORKFLOW ÉTAPES
    # ================================================================
    path('workflow/', views_parametres.workflow_etapes_liste, name='workflow_etapes_liste'),
    path('workflow/ajouter/', views_parametres.workflow_etape_modifier, name='workflow_etape_ajouter'),
    path('workflow/<int:pk>/modifier/', views_parametres.workflow_etape_modifier, name='workflow_etape_modifier'),
    path('workflow/<int:pk>/supprimer/', views_parametres.workflow_etape_supprimer, name='workflow_etape_supprimer'),
    path('workflow/reordonner/', views_parametres.workflow_etapes_reordonner, name='workflow_etapes_reordonner'),
    
    # ================================================================
    # DÉPARTEMENTS
    # ================================================================
    path('departements/', views_parametres.departements_liste, name='departements_liste'),
    path('departements/ajouter/', views_parametres.departement_modifier, name='departement_ajouter'),
    path('departements/<int:pk>/modifier/', views_parametres.departement_modifier, name='departement_modifier'),
    path('departements/<int:pk>/toggle-actif/', views_parametres.departement_toggle_actif, name='departement_toggle_actif'),
    
    # ================================================================
    # SITES
    # ================================================================
    path('sites/', views_parametres.sites_liste, name='sites_liste'),
    path('sites/ajouter/', views_parametres.site_modifier, name='site_ajouter'),
    path('sites/<int:pk>/modifier/', views_parametres.site_modifier, name='site_modifier'),
    path('sites/<int:pk>/toggle-actif/', views_parametres.site_toggle_actif, name='site_toggle_actif'),
    
    # ================================================================
    # POSTES
    # ================================================================
    path('postes/', views_parametres.postes_liste, name='postes_liste'),
    path('postes/ajouter/', views_parametres.poste_modifier, name='poste_ajouter'),
    path('postes/<int:pk>/modifier/', views_parametres.poste_modifier, name='poste_modifier'),
    path('postes/<int:pk>/toggle-actif/', views_parametres.poste_toggle_actif, name='poste_toggle_actif'),
    
    # ================================================================
    # MOTIFS D'ABSENCE
    # ================================================================
    path('motifs-absence/', views_parametres.motifs_absence_liste, name='motifs_absence_liste'),
    path('motifs-absence/ajouter/', views_parametres.motif_absence_modifier, name='motif_absence_ajouter'),
    path('motifs-absence/<int:pk>/modifier/', views_parametres.motif_absence_modifier, name='motif_absence_modifier'),
    path('motifs-absence/<int:pk>/toggle-actif/', views_parametres.motif_absence_toggle_actif, name='motif_absence_toggle_actif'),
    path('motifs-absence/<int:pk>/supprimer/', views_parametres.motif_absence_supprimer, name='motif_absence_supprimer'),
    
    # ================================================================
    # EXPORT / IMPORT
    # ================================================================
    path('export/', views_parametres.parametres_export, name='parametres_export'),
    path('import/', views_parametres.parametres_import, name='parametres_import'),
]


# ================================================================
# DOCUMENTATION DES URLS PARAMÈTRES
# ================================================================
"""
Structure des URLs pour les paramètres globaux et workflow:

/parametres/
├── /                           → Dashboard principal paramètres
│
├── config-kelio/               → Configuration API Kelio (SINGLETON)
│   ├── /                       → Affichage de la configuration unique
│   ├── modifier/               → Créer/Modifier la configuration
│   ├── tester/                 → Tester la connexion API
│   ├── toggle-actif/           → Activer/désactiver la config
│   ├── vider-cache/            → Vider le cache Kelio
│   └── sync/                   → Lancer une synchronisation
│
├── config-scoring/             → Configuration Scoring
│   ├── /                       → Liste des configurations
│   ├── ajouter/                → Ajouter une configuration
│   └── <pk>/modifier/          → Modifier une configuration
│
├── cache-kelio/                → Cache API Kelio
│   ├── /                       → Liste des entrées de cache
│   ├── purger/                 → Purger le cache
│   └── <pk>/supprimer/         → Supprimer une entrée
│
├── workflow/                   → Étapes de workflow
│   ├── /                       → Liste des étapes
│   ├── ajouter/                → Ajouter une étape
│   ├── <pk>/modifier/          → Modifier une étape
│   ├── <pk>/supprimer/         → Supprimer une étape
│   └── reordonner/             → Réordonner les étapes (drag & drop)
│
├── departements/               → Gestion des départements
│   ├── /                       → Liste des départements
│   ├── ajouter/                → Ajouter un département
│   ├── <pk>/modifier/          → Modifier un département
│   └── <pk>/toggle-actif/      → Activer/désactiver
│
├── sites/                      → Gestion des sites
│   ├── /                       → Liste des sites
│   ├── ajouter/                → Ajouter un site
│   ├── <pk>/modifier/          → Modifier un site
│   └── <pk>/toggle-actif/      → Activer/désactiver
│
├── postes/                     → Gestion des postes
│   ├── /                       → Liste des postes
│   ├── ajouter/                → Ajouter un poste
│   ├── <pk>/modifier/          → Modifier un poste
│   └── <pk>/toggle-actif/      → Activer/désactiver
│
├── motifs-absence/             → Gestion des motifs d'absence
│   ├── /                       → Liste des motifs
│   ├── ajouter/                → Ajouter un motif
│   ├── <pk>/modifier/          → Modifier un motif
│   ├── <pk>/toggle-actif/      → Activer/désactiver un motif
│   └── <pk>/supprimer/         → Supprimer un motif
│
├── export/                     → Export des paramètres (JSON/Excel)
└── import/                     → Import des paramètres
"""

# models_parametres.py
"""
Modèles pour la gestion des paramètres globaux et workflow.
À ajouter au fichier models.py existant ou à importer.
"""

from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator, RegexValidator
from django.utils import timezone


class TimestampedModel(models.Model):
    """Modèle abstrait avec timestamps automatiques"""
    date_creation = models.DateTimeField(auto_now_add=True, verbose_name="Date de création")
    date_modification = models.DateTimeField(auto_now=True, verbose_name="Date de modification")
    
    class Meta:
        abstract = True


class ActiveModel(models.Model):
    """Modèle abstrait avec gestion de l'état actif"""
    actif = models.BooleanField(default=True, verbose_name="Actif")
    
    class Meta:
        abstract = True


# ================================================================
# CONFIGURATION API KELIO
# ================================================================

class ConfigurationApiKelio(TimestampedModel, ActiveModel):
    """Configuration de connexion à l'API Kelio"""
    
    nom = models.CharField(
        max_length=100, 
        default="Configuration par défaut",
        verbose_name="Nom de la configuration"
    )
    url_base = models.URLField(
        verbose_name="URL de base de l'API",
        help_text="URL de l'API Kelio (ex: https://api.kelio.example.com/v1)"
    )
    cle_api = models.CharField(
        max_length=255,
        verbose_name="Clé API",
        help_text="Clé d'authentification pour l'API Kelio"
    )
    timeout = models.IntegerField(
        default=30,
        validators=[MinValueValidator(5), MaxValueValidator(120)],
        verbose_name="Timeout (secondes)",
        help_text="Délai d'attente maximum pour les requêtes API"
    )
    retry_count = models.IntegerField(
        default=3,
        validators=[MinValueValidator(0), MaxValueValidator(10)],
        verbose_name="Nombre de tentatives",
        help_text="Nombre de tentatives en cas d'échec de connexion"
    )
    
    # Planification de synchronisation
    sync_auto = models.BooleanField(
        default=True,
        verbose_name="Synchronisation automatique"
    )
    intervalle_sync_minutes = models.IntegerField(
        default=60,
        validators=[MinValueValidator(15), MaxValueValidator(1440)],
        verbose_name="Intervalle de synchronisation (minutes)"
    )
    
    # Statistiques de synchronisation
    derniere_sync = models.DateTimeField(
        null=True, 
        blank=True,
        verbose_name="Dernière synchronisation"
    )
    derniere_sync_reussie = models.BooleanField(
        default=False,
        verbose_name="Dernière sync réussie"
    )
    message_derniere_sync = models.TextField(
        blank=True,
        verbose_name="Message de dernière synchronisation"
    )
    
    class Meta:
        verbose_name = "Configuration API Kelio"
        verbose_name_plural = "Configurations API Kelio"
        ordering = ['-actif', '-date_modification']
    
    def __str__(self):
        status = "✓" if self.actif else "✗"
        return f"{status} {self.nom}"
    
    def save(self, *args, **kwargs):
        if self.actif:
            ConfigurationApiKelio.objects.exclude(pk=self.pk).update(actif=False)
        super().save(*args, **kwargs)


# ================================================================
# CONFIGURATION SCORING
# ================================================================

class ConfigurationScoring(TimestampedModel, ActiveModel):
    """Configuration des critères de scoring pour la sélection des candidats"""
    
    nom = models.CharField(
        max_length=100,
        default="Barèmes de scoring",
        verbose_name="Nom de la configuration"
    )
    description = models.TextField(
        blank=True,
        verbose_name="Description"
    )
    
    # Poids des critères (doivent sommer à 1.0 = 100%)
    poids_similarite_poste = models.FloatField(
        default=0.25,
        validators=[MinValueValidator(0), MaxValueValidator(1)],
        verbose_name="Poids similarité de poste",
        help_text="Importance de l'adéquation avec le poste demandé (0-1)"
    )
    poids_competences = models.FloatField(
        default=0.25,
        validators=[MinValueValidator(0), MaxValueValidator(1)],
        verbose_name="Poids des compétences",
        help_text="Importance des compétences techniques (0-1)"
    )
    poids_experience = models.FloatField(
        default=0.20,
        validators=[MinValueValidator(0), MaxValueValidator(1)],
        verbose_name="Poids de l'expérience",
        help_text="Importance de l'expérience professionnelle (0-1)"
    )
    poids_disponibilite = models.FloatField(
        default=0.15,
        validators=[MinValueValidator(0), MaxValueValidator(1)],
        verbose_name="Poids de la disponibilité",
        help_text="Importance de la disponibilité sur la période (0-1)"
    )
    poids_proximite = models.FloatField(
        default=0.10,
        validators=[MinValueValidator(0), MaxValueValidator(1)],
        verbose_name="Poids de la proximité",
        help_text="Importance de la proximité géographique (0-1)"
    )
    poids_anciennete = models.FloatField(
        default=0.05,
        validators=[MinValueValidator(0), MaxValueValidator(1)],
        verbose_name="Poids de l'ancienneté",
        help_text="Importance de l'ancienneté dans l'entreprise (0-1)"
    )
    
    # Bonus hiérarchiques (points ajoutés au score)
    bonus_proposition_humaine = models.IntegerField(
        default=5,
        validators=[MinValueValidator(0), MaxValueValidator(50)],
        verbose_name="Bonus proposition humaine",
        help_text="Points bonus si un humain propose ce candidat"
    )
    bonus_manager_direct = models.IntegerField(
        default=12,
        validators=[MinValueValidator(0), MaxValueValidator(50)],
        verbose_name="Bonus manager direct",
        help_text="Points bonus si validé par le manager direct"
    )
    bonus_chef_equipe = models.IntegerField(
        default=8,
        validators=[MinValueValidator(0), MaxValueValidator(50)],
        verbose_name="Bonus chef d'équipe",
        help_text="Points bonus si validé par le chef d'équipe"
    )
    bonus_responsable = models.IntegerField(
        default=15,
        validators=[MinValueValidator(0), MaxValueValidator(50)],
        verbose_name="Bonus responsable",
        help_text="Points bonus si validé par le responsable"
    )
    bonus_directeur = models.IntegerField(
        default=18,
        validators=[MinValueValidator(0), MaxValueValidator(50)],
        verbose_name="Bonus directeur",
        help_text="Points bonus si validé par le directeur"
    )
    bonus_rh = models.IntegerField(
        default=20,
        validators=[MinValueValidator(0), MaxValueValidator(50)],
        verbose_name="Bonus RH",
        help_text="Points bonus si validé par les RH"
    )
    bonus_admin = models.IntegerField(
        default=20,
        validators=[MinValueValidator(0), MaxValueValidator(50)],
        verbose_name="Bonus admin",
        help_text="Points bonus si validé par un administrateur"
    )
    
    # Pénalités (points retirés du score)
    penalite_indisponibilite_partielle = models.IntegerField(
        default=15,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        verbose_name="Pénalité indisponibilité partielle",
        help_text="Points retirés si le candidat est partiellement disponible"
    )
    penalite_indisponibilite_totale = models.IntegerField(
        default=50,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        verbose_name="Pénalité indisponibilité totale",
        help_text="Points retirés si le candidat n'est pas disponible"
    )
    penalite_distance_excessive = models.IntegerField(
        default=10,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        verbose_name="Pénalité distance excessive",
        help_text="Points retirés si le candidat est trop éloigné"
    )
    
    # Configuration par défaut
    configuration_par_defaut = models.BooleanField(
        default=True,
        verbose_name="Configuration par défaut"
    )
    
    class Meta:
        verbose_name = "Configuration Scoring"
        verbose_name_plural = "Configurations Scoring"
        ordering = ['-actif', 'nom']
    
    def __str__(self):
        status = "✓" if self.actif else "✗"
        return f"{status} {self.nom}"
    
    @property
    def total_poids(self):
        """Calcule le total des poids (doit être égal à 1.0)"""
        return (self.poids_similarite_poste + self.poids_competences + 
                self.poids_experience + self.poids_disponibilite + 
                self.poids_proximite + self.poids_anciennete)
    
    @property
    def poids_valides(self):
        """Vérifie si le total des poids est valide (100%)"""
        return abs(self.total_poids - 1.0) < 0.01
    
    def save(self, *args, **kwargs):
        # Singleton: un seul enregistrement actif par défaut
        if self.configuration_par_defaut:
            ConfigurationScoring.objects.exclude(pk=self.pk).update(configuration_par_defaut=False)
        super().save(*args, **kwargs)


# ================================================================
# CACHE API KELIO
# ================================================================

class CacheApiKelio(models.Model):
    """Cache des données API Kelio pour améliorer les performances"""
    
    TYPE_DONNEE_CHOICES = [
        ('EMPLOYES', 'Liste des employés'),
        ('ABSENCES', 'Données d\'absences'),
        ('PRESENCES', 'Données de présence'),
        ('DEPARTEMENTS', 'Départements'),
        ('SITES', 'Sites'),
        ('POSTES', 'Postes'),
        ('PLANNING', 'Planning'),
        ('AUTRE', 'Autre'),
    ]
    
    cle = models.CharField(
        max_length=255,
        unique=True,
        verbose_name="Clé de cache"
    )
    type_donnee = models.CharField(
        max_length=50,
        choices=TYPE_DONNEE_CHOICES,
        default='AUTRE',
        verbose_name="Type de donnée"
    )
    valeur = models.JSONField(
        verbose_name="Valeur cachée"
    )
    
    date_creation = models.DateTimeField(auto_now_add=True)
    date_expiration = models.DateTimeField(
        verbose_name="Date d'expiration"
    )
    
    nb_hits = models.IntegerField(default=0, verbose_name="Nombre d'accès")
    derniere_utilisation = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        verbose_name = "Cache API Kelio"
        verbose_name_plural = "Cache API Kelio"
        ordering = ['-date_creation']
    
    def __str__(self):
        return f"{self.type_donnee}: {self.cle[:50]}"
    
    @property
    def est_expire(self):
        return timezone.now() > self.date_expiration
    
    def enregistrer_hit(self):
        self.nb_hits += 1
        self.derniere_utilisation = timezone.now()
        self.save(update_fields=['nb_hits', 'derniere_utilisation'])


# ================================================================
# WORKFLOW ÉTAPES
# ================================================================

class WorkflowEtape(TimestampedModel, ActiveModel):
    """Définition des étapes du workflow de validation"""
    
    TYPE_VALIDATEUR_CHOICES = [
        ('MANAGER', 'Manager direct'),
        ('N1', 'Responsable N+1'),
        ('N2', 'Directeur N+2'),
        ('RH', 'Ressources Humaines'),
        ('ADMIN', 'Administrateur'),
    ]
    
    nom = models.CharField(max_length=100, verbose_name="Nom de l'étape")
    code = models.CharField(
        max_length=20,
        unique=True,
        validators=[RegexValidator(r'^[A-Z0-9_]{2,20}$', 'Code invalide')],
        verbose_name="Code"
    )
    description = models.TextField(blank=True, verbose_name="Description")
    
    ordre = models.IntegerField(
        default=1,
        validators=[MinValueValidator(1), MaxValueValidator(99)],
        verbose_name="Ordre"
    )
    
    type_validateur = models.CharField(
        max_length=20,
        choices=TYPE_VALIDATEUR_CHOICES,
        verbose_name="Type de validateur"
    )
    
    delai_max_heures = models.IntegerField(
        default=48,
        validators=[MinValueValidator(1), MaxValueValidator(720)],
        verbose_name="Délai maximum (heures)"
    )
    
    notification_email = models.BooleanField(default=True, verbose_name="Notification email")
    escalade_auto = models.BooleanField(default=False, verbose_name="Escalade automatique")
    
    etape_escalade = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='etapes_source',
        verbose_name="Étape d'escalade"
    )
    
    class Meta:
        verbose_name = "Étape de workflow"
        verbose_name_plural = "Étapes de workflow"
        ordering = ['ordre']
    
    def __str__(self):
        return f"{self.ordre}. {self.nom}"


# ================================================================
# MOTIF D'ABSENCE
# ================================================================

class MotifAbsence(TimestampedModel, ActiveModel):
    """Motifs d'absence disponibles dans le système"""
    
    TYPE_ABSENCE_CHOICES = [
        ('CONGE', 'Congé'),
        ('MALADIE', 'Maladie'),
        ('FORMATION', 'Formation'),
        ('MISSION', 'Mission'),
        ('MATERNITE', 'Maternité/Paternité'),
        ('ABSENCE', 'Absence autre'),
    ]
    
    code = models.CharField(
        max_length=20,
        unique=True,
        validators=[RegexValidator(r'^[A-Z0-9_]{2,20}$', 'Code invalide')],
        verbose_name="Code"
    )
    libelle = models.CharField(max_length=100, verbose_name="Libellé")
    description = models.TextField(blank=True, verbose_name="Description")
    
    type_absence = models.CharField(
        max_length=20,
        choices=TYPE_ABSENCE_CHOICES,
        default='ABSENCE',
        verbose_name="Type d'absence"
    )
    
    couleur = models.CharField(
        max_length=7,
        default='#6c757d',
        validators=[RegexValidator(r'^#[0-9A-Fa-f]{6}$', 'Couleur hexadécimale invalide')],
        verbose_name="Couleur"
    )
    
    decompte_conges = models.BooleanField(default=False, verbose_name="Décompte des congés")
    justificatif_requis = models.BooleanField(default=False, verbose_name="Justificatif requis")
    
    kelio_code = models.CharField(max_length=50, blank=True, verbose_name="Code Kelio")
    
    class Meta:
        verbose_name = "Motif d'absence"
        verbose_name_plural = "Motifs d'absence"
        ordering = ['type_absence', 'libelle']
    
    def __str__(self):
        return f"{self.code} - {self.libelle}"

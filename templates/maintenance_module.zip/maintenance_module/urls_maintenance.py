# -*- coding: utf-8 -*-
"""
URLs pour le module Maintenance - Sauvegarde et Optimisation
À inclure dans urls.py principal avec: path('', include('mainapp.urls_maintenance'))
"""

from django.urls import path
from . import views_maintenance

urlpatterns = [
    # Dashboard principal
    path('interim/maintenance/', views_maintenance.admin_maintenance, name='admin_maintenance'),
    
    # Sauvegardes
    path('interim/maintenance/sauvegardes/', views_maintenance.backup_liste, name='backup_liste'),
    path('interim/maintenance/sauvegardes/creer/', views_maintenance.backup_creer, name='backup_creer'),
    path('interim/maintenance/sauvegardes/telecharger/<str:filename>/', views_maintenance.backup_telecharger, name='backup_telecharger'),
    path('interim/maintenance/sauvegardes/supprimer/<str:filename>/', views_maintenance.backup_supprimer, name='backup_supprimer'),
    path('interim/maintenance/sauvegardes/restaurer/<str:filename>/', views_maintenance.backup_restaurer, name='backup_restaurer'),
    
    # Optimisation
    path('interim/maintenance/optimisation/', views_maintenance.optimisation_dashboard, name='optimisation_dashboard'),
    path('interim/maintenance/optimisation/vacuum/', views_maintenance.optimisation_vacuum, name='optimisation_vacuum'),
    path('interim/maintenance/optimisation/clear-cache/', views_maintenance.optimisation_clear_cache, name='optimisation_clear_cache'),
    path('interim/maintenance/optimisation/clear-sessions/', views_maintenance.optimisation_clear_sessions, name='optimisation_clear_sessions'),
    path('interim/maintenance/optimisation/archive-logs/', views_maintenance.optimisation_archive_logs, name='optimisation_archive_logs'),
    
    # AJAX
    path('interim/maintenance/stats/ajax/', views_maintenance.maintenance_stats_ajax, name='maintenance_stats_ajax'),
]

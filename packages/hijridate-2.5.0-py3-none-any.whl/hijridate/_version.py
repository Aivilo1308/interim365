"""HijriDate package version."""

__version__ = "2.5.0"
